export default function () {
  this.title = ''
  this.text = ''
}
