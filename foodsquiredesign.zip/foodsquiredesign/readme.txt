App screen design
